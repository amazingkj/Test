create table ranking(
r_no number(38),
r_sum number(38),
r_avg number(38),
r_putting number(38),
r_maxrange number(38),
r_avgrange number(38)
/* r_rank number(38), ��ũ�� �����ͺ��̽� ���� ���������? */
);

create sequence r_no_seq
start with 1
increment by 1
nocache;

insert into ranking values(r_no_seq.nextval,0,0,0,0,0,0,0,0);

select * from ranking order by r_no desc;

select * from ranking rownum

create sequence test_r_no
start with 1
increment by 1
nocache;

insert into ranking values(test_m_no.nextval,0,0,1.5,100,100);
insert into ranking values(test_m_no.nextval,-3,-3,1.0,150,150);
insert into ranking values(test_m_no.nextval,-5,-5,1.0,200,200);



