package Main;

import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class Popup_Agree extends JFrame{
	JLabel announce;
	JButton ok;
	Popup_Agree(){
		setLocationRelativeTo(null);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setSize(480,240);
		setVisible(true);
		setResizable(false);
		
		set();
		init();
		layouts();
	}
	
	void set() {
		announce = new JLabel("약관에 모두 동의해야 합니다.");
		ok = new JButton("확인");
		ok.addMouseListener(new MouseAdapter() {

			@Override
			public void mouseClicked(MouseEvent e) {
				dispose();
				
			}
			
		});
	}
	
	void init() {
		add(announce);
		add(ok);
	}
	
	void layouts() {
		setLayout(null);
		announce.setBounds(120,50,200,50);
		ok.setBounds(180,100,100,70);
	}
}
