package Main;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class Popup_findID extends JFrame{
	String DummyData;
	JLabel whatisyourID1,whatisyourID2,whatisyourID3;
	JButton ok;
	
	Popup_findID(){
		setLocationRelativeTo(null);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setSize(480,240);
		setVisible(true);
		setResizable(false);
		setLayout(null);
		
		DummyData = "(데이터베이스에 저장된 아이디를 가져오세요)";;
		
		whatisyourID1 = new JLabel();
		whatisyourID2 = new JLabel();
		whatisyourID3 = new JLabel();
		whatisyourID1.setText("당신의 아이디는");
		whatisyourID2.setText(DummyData);
		whatisyourID3.setText("입니다.");
		add(whatisyourID1);
		add(whatisyourID2);
		add(whatisyourID3);
		whatisyourID1.setBounds(40,10,300,30);
		whatisyourID2.setBounds(40,50,300,30);
		whatisyourID3.setBounds(40,90,300,30);
		
		
		ok = new JButton("확인");
		ok.addMouseListener(new MouseAdapter() {

			@Override
			public void mouseClicked(MouseEvent e) {
				dispose();
			}
			
		});
		add(ok);
		ok.setBounds(100,130,75,50);
	}

}
