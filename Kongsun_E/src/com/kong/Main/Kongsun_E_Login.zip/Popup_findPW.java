package Main;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class Popup_findPW extends JFrame{
	String DummyData;
	JLabel whatisyourPW1,whatisyourPW2,whatisyourPW3;
	JButton ok;
	
	Popup_findPW(){
		setLocationRelativeTo(null);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setSize(480,240);
		setVisible(true);
		setResizable(false);
		setLayout(null);
		
		//1안 - 비밀번호 초기화하기
		//2안 - 비밀번호 찾아주기
		
		DummyData = "(초기화에 쓸 비밀번호를 여기에 쓰세요)"; //이후 데이터베이스에 저장된 비밀번호 데이터도 바꾸게 해줘야함.
		
		/*
		 * DummyData = "(데이터베이스에 저장된 비밀번호를 여기로 가져오기)";
		 * whatisyourPW1 = new JLabel();
		whatisyourPW2 = new JLabel();
		whatisyourPW3 = new JLabel();
		whatisyourPW1.setText("당신의 비밀번호는");
		whatisyourPW2.setText(DummyData);
		whatisyourPW3.setText("입니다.");
		add(whatisyourPW1);
		add(whatisyourPW2);
		add(whatisyourPW3);
		whatisyourPW1.setBounds(40,10,300,30);
		whatisyourPW2.setBounds(40,50,300,30);
		whatisyourPW3.setBounds(40,90,300,30);
 
		 */
		
		whatisyourPW1 = new JLabel();
		whatisyourPW2 = new JLabel();
		whatisyourPW3 = new JLabel();
		whatisyourPW1.setText("당신의 초기화된 비밀번호는");
		whatisyourPW2.setText(DummyData);
		whatisyourPW3.setText("입니다.");
		add(whatisyourPW1);
		add(whatisyourPW2);
		add(whatisyourPW3);
		whatisyourPW1.setBounds(40,10,300,30);
		whatisyourPW2.setBounds(40,50,300,30);
		whatisyourPW3.setBounds(40,90,300,30);
		
		
		ok = new JButton("확인");
		ok.addMouseListener(new MouseAdapter() {

			@Override
			public void mouseClicked(MouseEvent e) {
				dispose();
			}
			
		});
		add(ok);
		ok.setBounds(100,130,75,50);
	}

}
