package Main;

import java.awt.Font;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.ScrollPaneConstants;

public class Start extends JFrame{
	
	JPanel LoginPanel = new JPanel();
	JPanel newAccountPanel = new JPanel();
	JPanel findIDPanel = new JPanel();
	JPanel findPWPanel = new JPanel();
	JPanel CeoPanel = new JPanel();
	JPanel Ceo2Panel = new JPanel();
	JPanel CustomerPanel = new JPanel();
	JPanel Customer2Panel = new JPanel();
	JPanel CreateSuccess = new JPanel();
	
	public Start(){
		setLocationRelativeTo(null);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setSize(480,800);
		setVisible(true);
		setResizable(false);
		
		//로그인화면
		add(LoginPanel);
		
		JTextField LO_logintxt;
		JPasswordField LO_password;
		JLabel LO_findID,LO_findPW,LO_border;
		JButton LO_loginbtn,LO_newaccountbtn,LO_exit;
		
		//--여기부터 set--//
		Font LO_f1 = new Font("맑은 고딕",Font.PLAIN,15);
		//Font f2 = new Font("맑은 고딕",Font.PLAIN,25);
		
		LO_logintxt = new JTextField(7);
		LO_logintxt.setFont(LO_f1);
				
		LO_password = new JPasswordField(7);
		
		LO_loginbtn = new JButton(new ImageIcon("./images/loginicon.png"));
		
		LO_newaccountbtn = new JButton(new ImageIcon("./images/newaccicon.png"));
		LO_newaccountbtn.addMouseListener(new MouseAdapter() {

			@Override
			public void mouseClicked(MouseEvent e) {
				getContentPane().removeAll();			
				repaint();
				add(newAccountPanel);
				newAccountPanel.setBounds(0,0,480,800);
				newAccountPanel.setVisible(true);
			}			
		});
		
		
		LO_findID = new JLabel();
		LO_findID.setFont(LO_f1);
		LO_findID.setText("아이디 찾기");
		LO_findID.addMouseListener(new MouseAdapter() {

			@Override
			public void mouseClicked(MouseEvent e) {
				getContentPane().removeAll();
				repaint();
				add(findIDPanel);
				findIDPanel.setBounds(0,0,480,800);
				findIDPanel.setVisible(true);
			}	
		});
		
		LO_border = new JLabel("|");
		LO_border.setFont(LO_f1);
		
		LO_findPW = new JLabel();
		LO_findPW.setFont(LO_f1);
		LO_findPW.setText("비밀번호 찾기");
		LO_findPW.addMouseListener(new MouseAdapter() {

			@Override
			public void mouseClicked(MouseEvent e) {
				getContentPane().removeAll();
				repaint();
				add(findPWPanel);
				findPWPanel.setBounds(0,0,480,800);
				findPWPanel.setVisible(true);
			}
			
		});
		
		LO_exit = new JButton("종료");
		LO_exit.addMouseListener(new MouseAdapter() {

			@Override
			public void mouseClicked(MouseEvent e) {
				dispose();
			}
			
		});
		//--여기까지 set--//
		
		//--여기부터 init--//
		LoginPanel.add(LO_logintxt);
		LoginPanel.add(LO_password);
		LoginPanel.add(LO_loginbtn);
		LoginPanel.add(LO_newaccountbtn);
		LoginPanel.add(LO_findID);
		LoginPanel.add(LO_border);
		LoginPanel.add(LO_findPW);
		LoginPanel.add(LO_exit);
		//--여기부터 init--//
						
		//--여기부터 layouts--//
		LoginPanel.setLayout(null);
		LO_logintxt.setBounds(90,240,300,45);
		LO_password.setBounds(90,300,300,45);
		LO_loginbtn.setBounds(95,380,290,60);
		LO_newaccountbtn.setBounds(165,500,150,90);
		LO_findID.setBounds(150,450,100,50);
		LO_border.setBounds(240,450,100,50);
		LO_findPW.setBounds(255,450,100,50);
		LO_exit.setBounds(200,640,80,50);
		//--여기까지 layouts--//
		//로그인화면 끝
		
		//회원가입창
		
		
		JButton NA_backspace,NA_customer,NA_ceo;
		
		//--여기부터 set--//
		NA_backspace = new JButton();
		NA_backspace.addMouseListener(new MouseAdapter() {

			@Override
			public void mouseClicked(MouseEvent e) {
				getContentPane().removeAll();
				repaint();
				add(LoginPanel);
				LoginPanel.setBounds(0,0,480,800);
				LoginPanel.setVisible(true);
			}
		});
		
		NA_customer = new JButton("개인회원");
		NA_customer.addMouseListener(new MouseAdapter() {

			@Override
			public void mouseClicked(MouseEvent e) {
				getContentPane().removeAll();
				repaint();
				add(CustomerPanel);
				CustomerPanel.setBounds(0,0,480,800);
				CustomerPanel.setVisible(true);
			}
			
		});
		
		NA_ceo = new JButton("사업자");
		NA_ceo.addMouseListener(new MouseAdapter() {

			@Override
			public void mouseClicked(MouseEvent e) {
				getContentPane().removeAll();
				repaint();
				add(CeoPanel);
				CeoPanel.setBounds(0,0,480,800);
				CeoPanel.setVisible(true);
			}
			
		});
		//--여기까지 set--//
		
		
		//--여기부터 init--//
		newAccountPanel.add(NA_backspace);
		newAccountPanel.add(NA_customer);
		newAccountPanel.add(NA_ceo);
		//--여기까지 init--//
		
		
		//--여기부터 layouts--//
		newAccountPanel.setLayout(null);
		NA_backspace.setBounds(10,10,25,25);
		NA_customer.setBounds(20,400,200,100);
		NA_ceo.setBounds(260,400,200,100);
		//--여기까지 layouts--//
		//회원가입창 끝
		
		
		//아이디찾기
		findIDPanel.setVisible(true);
		JTextField FI_name,FI_phonetxt;
		JButton FI_backspace,FI_ok;
		JLabel FI_nametip,FI_phonetip;
		
		//--여기부터 set--//
		Font FI_f1 = new Font("맑은 고딕",Font.BOLD,12);
		
		FI_backspace = new JButton();
		FI_backspace.addMouseListener(new MouseAdapter() {

			@Override
			public void mouseClicked(MouseEvent e) {
				getContentPane().removeAll();
				repaint();
				add(LoginPanel);
				LoginPanel.setBounds(0,0,480,800);
				LoginPanel.setVisible(true);
			}
			
		});
		
		FI_name = new JTextField();
		
		FI_nametip = new JLabel();
		FI_nametip.setFont(FI_f1);
		FI_nametip.setText("아이디");
		
		FI_phonetxt = new JTextField();
		FI_phonetxt.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				if(FI_phonetxt.getText().length() > 0) {
					if(e.getKeyChar() != KeyEvent.VK_BACK_SPACE) {
						if(FI_phonetxt.getText().length() == 3) {
							FI_phonetxt.setText(FI_phonetxt.getText()+"-");
						}else if(FI_phonetxt.getText().length() == 8) {
							FI_phonetxt.setText(FI_phonetxt.getText()+"-");
						}
					}
				}
			}
		});
		
		FI_phonetip = new JLabel();
		FI_phonetip.setFont(FI_f1);
		FI_phonetip.setText("전화번호");
		
		FI_ok = new JButton("아이디 찾기");
		FI_ok.addMouseListener(new MouseAdapter() {

			@Override
			public void mouseClicked(MouseEvent e) {
				new Popup_findID();
			}
			
		});
		//--여기까지 set--//
		
		
		//--여기부터 init--//
		findIDPanel.add(FI_backspace);
		findIDPanel.add(FI_name);
		findIDPanel.add(FI_nametip);
		findIDPanel.add(FI_phonetxt);
		findIDPanel.add(FI_phonetip);
		findIDPanel.add(FI_ok);
		//--여기까지 init--//
		
		
		//--여기부터 layouts--//
		findIDPanel.setLayout(null);
		FI_backspace.setBounds(10,10,25,25);
		FI_name.setBounds(210,50,200,25);
		FI_nametip.setBounds(110,50,100,25);
		FI_phonetxt.setBounds(210,100,200,25);
		FI_phonetip.setBounds(110,100,100,25);
		FI_ok.setBounds(110,250,150,50);
		//--여기까지 layouts--//
		//아이디찾기 끝
		
		
		//비밀번호찾기
		findPWPanel.setVisible(true);
		JTextField FP_name,FP_idtxt,FP_phonetxt;
		JButton FP_backspace,FP_ok;
		JLabel FP_nametip,FP_idtip,FP_phonetip;
		
		//--여기부터 set--//
		Font FP_f1 = new Font("맑은 고딕",Font.BOLD,12);
		
		FP_backspace = new JButton();
		FP_backspace.addMouseListener(new MouseAdapter() {

			@Override
			public void mouseClicked(MouseEvent e) {
				getContentPane().removeAll();
				repaint();
				add(LoginPanel);
				LoginPanel.setBounds(0,0,480,800);
				LoginPanel.setVisible(true);
			}
			
		});
		
		FP_name = new JTextField();
		FP_nametip = new JLabel();
		FP_nametip.setFont(FP_f1);
		FP_nametip.setText("이름");
		
		FP_idtxt = new JTextField();
		
		FP_idtip = new JLabel();
		FP_idtip.setFont(FP_f1);
		FP_idtip.setText("아이디");
		
		FP_phonetxt = new JTextField();
		FP_phonetxt.addKeyListener(new KeyAdapter() {

			@Override
			public void keyReleased(KeyEvent e) {
				if(FP_phonetxt.getText().length() > 0) {
					if(e.getKeyChar() != KeyEvent.VK_BACK_SPACE) {
						if(FP_phonetxt.getText().length() == 3) {
							FP_phonetxt.setText(FP_phonetxt.getText()+"-");
						}else if(FP_phonetxt.getText().length() == 8) {
							FP_phonetxt.setText(FP_phonetxt.getText()+"-");
						}
					}
				}
			}
		});
		
		FP_phonetip = new JLabel();
		FP_phonetip.setFont(FP_f1);
		FP_phonetip.setText("전화번호");
		
		FP_ok = new JButton("비밀번호 초기화");
		FP_ok.addMouseListener(new MouseAdapter() {

			@Override
			public void mouseClicked(MouseEvent e) {
				new Popup_findPW();
			}
			
		});
		//--여기까지 set--//
		
		
		//--여기부터 init--//
		findPWPanel.add(FP_backspace);
		findPWPanel.add(FP_name);
		findPWPanel.add(FP_nametip);
		findPWPanel.add(FP_idtxt);
		findPWPanel.add(FP_idtip);
		findPWPanel.add(FP_phonetxt);
		findPWPanel.add(FP_phonetip);
		findPWPanel.add(FP_ok);
		//--여기까지 init--//
		
		
		//--여기부터 layouts--//
		findPWPanel.setLayout(null);
		FP_backspace.setBounds(10,10,25,25);
		FP_name.setBounds(210,50,200,25);
		FP_nametip.setBounds(110,50,100,25);
		FP_idtxt.setBounds(210,100,200,25);
		FP_idtip.setBounds(110,100,100,25);
		FP_phonetxt.setBounds(210,150,200,25);
		FP_phonetip.setBounds(110,150,200,25);
		FP_ok.setBounds(110,250,150,50);
		//--여기부터 layouts--//
		//비밀번호찾기 끝
		
		
		//사업자
		CeoPanel.setVisible(true);
		JLabel CEO_alllb,CEO_lb1,CEO_lb2,CEO_lb3,CEO_lb4,CEO_lb5;
		JCheckBox CEO_all;
		JCheckBox CEO_c1,CEO_c2,CEO_c3,CEO_c4,CEO_c5;
		JButton CEO_backspace,CEO_next;
		
		//--여기부터 set--//
		CEO_backspace = new JButton();
		CEO_backspace.addMouseListener(new MouseAdapter() {

			@Override
			public void mouseClicked(MouseEvent e) {
				getContentPane().removeAll();
				repaint();
				add(newAccountPanel);
				newAccountPanel.setBounds(0,0,480,800);
				newAccountPanel.setVisible(true);
			}
			
		});
		

		CEO_all = new JCheckBox();
		CEO_c1 = new JCheckBox();
		CEO_c2 = new JCheckBox();
		CEO_c3 = new JCheckBox();
		CEO_c4 = new JCheckBox();
		CEO_c5 = new JCheckBox();
		CEO_all.addItemListener(new ItemListener() {

			@Override
			public void itemStateChanged(ItemEvent e) {
				//all.setSelected(true);
				CEO_c1.setSelected(true);
				CEO_c2.setSelected(true);
				CEO_c3.setSelected(true);
				CEO_c4.setSelected(true);
				CEO_c5.setSelected(true);
			}
			
		});
		
		CEO_c1.addItemListener(new ItemListener() {

			@Override
			public void itemStateChanged(ItemEvent e) {
				CEO_all.setSelected(false);
			}
			
		});		
		
		CEO_c2.addItemListener(new ItemListener() {

			@Override
			public void itemStateChanged(ItemEvent e) {
				CEO_all.setSelected(false);
			}
			
		});
				
		CEO_c3.addItemListener(new ItemListener() {

			@Override
			public void itemStateChanged(ItemEvent e) {
				CEO_all.setSelected(false);
			}
			
		});
				
		CEO_c4.addItemListener(new ItemListener() {

			@Override
			public void itemStateChanged(ItemEvent e) {
				CEO_all.setSelected(false);
			}
			
		});
				
		CEO_c5.addItemListener(new ItemListener() {

			@Override
			public void itemStateChanged(ItemEvent e) {
				CEO_all.setSelected(false);
			}
			
		});
						
		CEO_alllb = new JLabel("모두 동의합니다.");
		
		CEO_lb1 = new JLabel("약관1");
		
		CEO_lb2 = new JLabel("약관2");
		
		CEO_lb3 = new JLabel("약관3");
		
		CEO_lb4 = new JLabel("약관4");
		
		CEO_lb5 = new JLabel("약관5");
		
		CEO_next = new JButton("가입하기");
		CEO_next.addMouseListener(new MouseAdapter() {

			@Override
			public void mouseClicked(MouseEvent e) {
				if(CEO_c1.isSelected() && CEO_c2.isSelected() && CEO_c3.isSelected() && CEO_c4.isSelected() && CEO_c5.isSelected() ) {
					CEO_all.setSelected(false);
					CEO_c1.setSelected(false);
					CEO_c2.setSelected(false);
					CEO_c3.setSelected(false);
					CEO_c4.setSelected(false);
					CEO_c5.setSelected(false);
					getContentPane().removeAll();
					repaint();
					add(Ceo2Panel);
					Ceo2Panel.setBounds(0,0,480,800);
					Ceo2Panel.setVisible(true);
				}else {
					new Popup_Agree();
				}
				
			}
			
		});
		//--여기까지 set--//
		
		
		//--여기부터 init--//
		CeoPanel.add(CEO_backspace);
		
		CeoPanel.add(CEO_all);
		CeoPanel.add(CEO_c1);
		CeoPanel.add(CEO_c2);
		CeoPanel.add(CEO_c3);
		CeoPanel.add(CEO_c4);
		CeoPanel.add(CEO_c5);
		
		CeoPanel.add(CEO_alllb);
		CeoPanel.add(CEO_lb1);
		CeoPanel.add(CEO_lb2);
		CeoPanel.add(CEO_lb3);
		CeoPanel.add(CEO_lb4);
		CeoPanel.add(CEO_lb5);
		
		CeoPanel.add(CEO_next);
		//--여기까지 init--//
		
		
		//--여기부터 layouts--//
		CeoPanel.setLayout(null);
		
		CEO_backspace.setBounds(10,10,50,50);
		
		CEO_all.setBounds(50,200,25,25);
		CEO_c1.setBounds(50,250,25,25);
		CEO_c2.setBounds(50,300,25,25);
		CEO_c3.setBounds(50,350,25,25);
		CEO_c4.setBounds(50,400,25,25);
		CEO_c5.setBounds(50,450,25,25);
		
		CEO_alllb.setBounds(100,200,200,25);
		CEO_lb1.setBounds(100,250,200,25);
		CEO_lb2.setBounds(100,300,200,25);
		CEO_lb3.setBounds(100,350,200,25);
		CEO_lb4.setBounds(100,400,200,25);
		CEO_lb5.setBounds(100,450,200,25);
		
		CEO_next.setBounds(100,600,200,80);
		//--여기까지 layouts--//
		//사업자 끝
		
		
		//사업자2
		
		JTextField CEO2_idtxt,CEO2_nametxt,CEO2_addrtxt,CEO2_phonetxt,CEO2_crntxt,CEO2_bntxt;
		JPasswordField CEO2_pwtxt,CEO2_pwchecktxt;
		JLabel CEO2_idtip,CEO2_pwtip,CEO2_pwchecktip,CEO2_nametip,CEO2_phonetip,CEO2_addrtip,CEO2_crntip,CEO2_bntip,CEO2_foodtip;
		JComboBox<String> CEO2_food;
		JButton CEO2_backspace,CEO2_imsibtn;
		
		boolean CEO2_id,CEO2_pw,CEO2_name,CEO2_address,CEO2_phone,CEO2_crn,CEO2_bn;
		
		//--여기부터 set--//
		CEO2_idtip = new JLabel();
		CEO2_idtip.setText("아이디를 입력하세요.");
		
		CEO2_pwtip = new JLabel();
		CEO2_pwtip.setText("비밀번호를 입력하세요.");
		
		CEO2_pwchecktip = new JLabel();
		CEO2_pwchecktip.setText("비밀번호를 입력하세요.");
		
		CEO2_nametip = new JLabel();
		CEO2_nametip.setText("이름을 입력하세요.");
		
		CEO2_addrtip = new JLabel();
		CEO2_addrtip.setText("주소를 입력하세요.");
		
		CEO2_phonetip = new JLabel();
		CEO2_phonetip.setText("전화번호를 입력하세요.");
		
		CEO2_crntip = new JLabel();
		CEO2_crntip.setText("사업자등록번호를 입력하세요.");
		
		CEO2_bntip = new JLabel();
		CEO2_bntip.setText("상호명을 입력하세요.");
		
		CEO2_foodtip = new JLabel();
		CEO2_foodtip.setText("요리분야를 선택하세요.");
		CEO2_backspace = new JButton();
		CEO2_backspace.addMouseListener(new MouseAdapter() {

			@Override
			public void mouseClicked(MouseEvent e) {
				getContentPane().removeAll();
				repaint();
				add(CeoPanel);
				CeoPanel.setBounds(0,0,480,800);
				CeoPanel.setVisible(true);
			}
			
		});
		
		CEO2_idtxt = new JTextField();
		
		CEO2_nametxt = new JTextField();
		
		CEO2_addrtxt = new JTextField();
		
		CEO2_phonetxt = new JTextField();
		
		CEO2_pwtxt = new JPasswordField();
		
		CEO2_pwchecktxt = new JPasswordField();
		
		CEO2_crntxt = new JTextField();
		
		CEO2_bntxt = new JTextField();
		
		
		CEO2_idtxt.addKeyListener(new KeyAdapter() {

			@Override
			public void keyReleased(KeyEvent e) {
				if(CEO2_idtxt.getText().length() > 0) {
					if(!(CEO2_idtxt.getText().matches("^[a-zA-Z0-9]*$"))) {
						CEO2_idtip.setText("영어 혹은 숫자만 입력가능합니다.");
						//id = false;
					}else {
						CEO2_idtip.setText("사용가능한 아이디입니다.");
						//id = true;
					}
				}else {
					CEO2_idtip.setText("아이디를 입력하세요.");
				}
			}
			
		});
				
		CEO2_nametxt.addKeyListener(new KeyAdapter() {

			@Override
			public void keyReleased(KeyEvent e) {
				if(CEO2_nametxt.getText().length() > 0) {
					if(!(CEO2_nametxt.getText().matches("^[ㄱ-ㅎㅏ-ㅣ가-힣]*$"))) {
						CEO2_nametip.setText("한글만 입력 가능합니다.");
						//name = false;
					}else {
						CEO2_nametip.setText("사용 가능한 이름입니다.");
						//name = true;
					}
				}else {
					CEO2_nametip.setText("이름을 입력하세요.");
				}
			}
			
		});		
		
		CEO2_addrtxt.addKeyListener(new KeyAdapter() {

			@Override
			public void keyReleased(KeyEvent e) {
				if(CEO2_addrtxt.getText().length() > 0) {
					//address = true;
				}else {
					//address = false;
				}
			}
		});
		
		
		CEO2_phonetxt.addKeyListener(new KeyAdapter() {

			@Override
			public void keyReleased(KeyEvent e) {
				if(CEO2_phonetxt.getText().length() > 0) {
					if(e.getKeyChar() != KeyEvent.VK_BACK_SPACE) {
						if(CEO2_phonetxt.getText().length() == 3) {
							CEO2_phonetxt.setText(CEO2_phonetxt.getText()+"-");
						}else if(CEO2_phonetxt.getText().length() == 8) {
							CEO2_phonetxt.setText(CEO2_phonetxt.getText()+"-");
						}
					}
					if(!(CEO2_phonetxt.getText().matches("^01(?:0|1|[6-9])-(?:\\d{3}|\\d{4})-\\d{4}$"))){
						CEO2_phonetip.setText("잘못된 번호입니다.");
						//phone = false;
					}else {
						CEO2_phonetip.setText("올바론 번호입니다.");
						//phone = true;
					}
				}else {
					CEO2_phonetip.setText("전화번호를 입력하세요.");
				}
			}
			
		});
				
		CEO2_pwtxt.addKeyListener(new KeyAdapter() {

			@Override
			public void keyReleased(KeyEvent e) {
				if(CEO2_pwtxt.getPassword().length > 0) {
					if(new String(CEO2_pwchecktxt.getPassword()).equals(new String(CEO2_pwtxt.getPassword()))) {
						CEO2_pwtip.setText("비밀번호가 일치합니다.");
						if(CEO2_pwtip.getText() == "비밀번호가 일치합니다.") {
							CEO2_pwchecktip.setText("비밀번호가 일치합니다.");
						}
					}else {
						CEO2_pwtip.setText("비밀번호가 일치하지 않습니다.");
					}
				}else {
					CEO2_pwtip.setText("비밀번호를 입력하세요.");
				}
			}
			
		});
				
		CEO2_pwchecktxt.addKeyListener(new KeyAdapter() {

			@Override
			public void keyReleased(KeyEvent e) {
				if(CEO2_pwchecktxt.getPassword().length > 0) {
					if(new String(CEO2_pwtxt.getPassword()).equals(new String(CEO2_pwchecktxt.getPassword()))) {
						CEO2_pwchecktip.setText("비밀번호가 일치합니다.");
						if(CEO2_pwchecktip.getText() == "비밀번호가 일치합니다.") {
							CEO2_pwtip.setText("비밀번호가 일치합니다.");
						}
						//pw = true;
					}else {
						CEO2_pwchecktip.setText("비밀번호가 일치하지 않습니다.");
						//pw = false;
					}
				}else {
					CEO2_pwchecktip.setText("비밀번호를 입력하세요.");
				}
			}
			
		});
		
		CEO2_crntxt.addKeyListener(new KeyAdapter() {

			@Override
			public void keyReleased(KeyEvent e) {
				if(CEO2_crntxt.getText().length() > 0) {
					if(e.getKeyChar() != KeyEvent.VK_BACK_SPACE) {
						if(CEO2_crntxt.getText().length() == 3) {
							CEO2_crntxt.setText(CEO2_crntxt.getText()+"-");
						}else if(CEO2_crntxt.getText().length() == 6){
							CEO2_crntxt.setText(CEO2_crntxt.getText()+"-");
						}
					if(!(CEO2_crntxt.getText().matches("([0-9]{3})-?([0-9]{2})-?([0-9]{5})"))) {
						CEO2_crntip.setText("잘못된 번호입니다.");
						//crn = false;
					}else {
						CEO2_crntip.setText("올바른 번호입니다.");
						//crn = true;
					}
					}
				}else {
					CEO2_crntip.setText("사업자등록번호를 입력하세요.");
				}
			}
			
		});
				
		CEO2_bntxt.addKeyListener(new KeyAdapter() {

			@Override
			public void keyReleased(KeyEvent e) {
				if(CEO2_bntxt.getText().length() > 0) {
					if(!(CEO2_bntxt.getText().matches("^[ㄱ-ㅎㅏ-ㅣ가-힣]*$"))) {
						CEO2_bntip.setText("한글만 입력 가능합니다.");
						//bn = false;
					}else {
						CEO2_bntip.setText("사용 가능한 상호명입니다.");
						//bn = true;
					}
				}
			}
			
		});
		
		CEO2_food = new JComboBox<String>();
		CEO2_food.addItem("한식");
		CEO2_food.addItem("중식");
		CEO2_food.addItem("일식");
		CEO2_food.addItem("양식");
		
				
		CEO2_imsibtn = new JButton("가입하기");
		CEO2_imsibtn.addMouseListener(new MouseAdapter() {

			@Override
			public void mouseClicked(MouseEvent e) {
				getContentPane().removeAll();
				repaint();
				add(CreateSuccess);
				CreateSuccess.setBounds(0,0,480,800);
				CreateSuccess.setVisible(true);
				//데이터베이스에 입력한거 넣기 작업하기
			}
			
		});
		//--여기까지 set--//
		
		
		//--여기부터 init--//
		Ceo2Panel.add(CEO2_backspace);
		Ceo2Panel.add(CEO2_idtxt);
		Ceo2Panel.add(CEO2_pwtxt);
		Ceo2Panel.add(CEO2_pwchecktxt);
		Ceo2Panel.add(CEO2_nametxt);
		Ceo2Panel.add(CEO2_addrtxt);
		Ceo2Panel.add(CEO2_phonetxt);
		Ceo2Panel.add(CEO2_crntxt);
		Ceo2Panel.add(CEO2_bntxt);
		Ceo2Panel.add(CEO2_food);
		Ceo2Panel.add(CEO2_idtip);
		Ceo2Panel.add(CEO2_pwtip);
		Ceo2Panel.add(CEO2_pwchecktip);
		Ceo2Panel.add(CEO2_nametip);
		Ceo2Panel.add(CEO2_addrtip);
		Ceo2Panel.add(CEO2_phonetip);
		Ceo2Panel.add(CEO2_crntip);
		Ceo2Panel.add(CEO2_bntip);
		Ceo2Panel.add(CEO2_foodtip);
		
		Ceo2Panel.add(CEO2_imsibtn);
		//--여기까지 init--//
		
		
		//--여기부터 layouts--//
		Ceo2Panel.setLayout(null);
		CEO2_backspace.setBounds(10,0,25,25);
		CEO2_idtxt.setBounds(10,50,200,25);
		CEO2_pwtxt.setBounds(10,100,200,25);
		CEO2_pwchecktxt.setBounds(10,150,200,25);
		CEO2_nametxt.setBounds(10,200,200,25);
		CEO2_addrtxt.setBounds(10,250,200,25);
		CEO2_phonetxt.setBounds(10,300,200,25);
		CEO2_crntxt.setBounds(10,350,200,25);
		CEO2_bntxt.setBounds(10,400,200,25);
		CEO2_food.setBounds(10,450,100,25);
		CEO2_idtip.setBounds(220,50,200,25);
		CEO2_pwtip.setBounds(220,100,200,25);
		CEO2_pwchecktip.setBounds(220,150,200,25);
		CEO2_nametip.setBounds(220,200,200,25);
		CEO2_addrtip.setBounds(220,250,200,25);
		CEO2_phonetip.setBounds(220,300,200,25);
		CEO2_crntip.setBounds(220,350,200,25);
		CEO2_bntip.setBounds(220,400,200,25);
		CEO2_foodtip.setBounds(220,450,200,25);
		
		
		CEO2_imsibtn.setBounds(100,600,200,80);
		//--여기까지 layouts--//
		Ceo2Panel.setVisible(true);
		
		//사업자2 끝
		
		
		//손님
		CustomerPanel.setVisible(true);
		
		JCheckBox CUS_all,CUS_c1,CUS_c2,CUS_c3,CUS_c4,CUS_c5;
		JLabel CUS_alllb,CUS_lb1,CUS_lb2,CUS_lb3,CUS_lb4,CUS_lb5;
		JButton CUS_backspace,CUS_next;
		
		//--여기부터 set--//
		CUS_backspace = new JButton();
		CUS_backspace.addMouseListener(new MouseAdapter() {

			@Override
			public void mouseClicked(MouseEvent e) {
				getContentPane().removeAll();
				repaint();
				add(newAccountPanel);
				newAccountPanel.setBounds(0,0,480,800);
				newAccountPanel.setVisible(true);
			}
			
		});
		
		CUS_all = new JCheckBox();
		CUS_c1 = new JCheckBox();
		CUS_c2 = new JCheckBox();
		CUS_c3 = new JCheckBox();
		CUS_c4 = new JCheckBox();
		CUS_c5 = new JCheckBox();
		CUS_all.addItemListener(new ItemListener() {

			@Override
			public void itemStateChanged(ItemEvent e) {
				//all.setSelected(true);
				CUS_c1.setSelected(true);
				CUS_c2.setSelected(true);
				CUS_c3.setSelected(true);
				CUS_c4.setSelected(true);
				CUS_c5.setSelected(true);
			}
			
		});
				
		CUS_c1.addItemListener(new ItemListener() {

			@Override
			public void itemStateChanged(ItemEvent e) {
				CUS_all.setSelected(false);
			}
			
		});
				
		CUS_c2.addItemListener(new ItemListener() {

			@Override
			public void itemStateChanged(ItemEvent e) {
				CUS_all.setSelected(false);
			}
			
		});
				
		CUS_c3.addItemListener(new ItemListener() {

			@Override
			public void itemStateChanged(ItemEvent e) {
				CUS_all.setSelected(false);
			}
			
		});
				
		CUS_c4.addItemListener(new ItemListener() {

			@Override
			public void itemStateChanged(ItemEvent e) {
				CUS_all.setSelected(false);
			}
			
		});
				
		CUS_c5.addItemListener(new ItemListener() {

			@Override
			public void itemStateChanged(ItemEvent e) {
				CUS_all.setSelected(false);
			}
			
		});
		
		CUS_alllb = new JLabel("모두 동의합니다.");
		
		CUS_lb1 = new JLabel("약관1");
		
		CUS_lb2 = new JLabel("약관2");
		
		CUS_lb3 = new JLabel("약관3");
		
		CUS_lb4 = new JLabel("약관4");
		
		CUS_lb5 = new JLabel("약관5");
		
		CUS_next = new JButton("가입하기");
		CUS_next.addMouseListener(new MouseAdapter() {

			@Override
			public void mouseClicked(MouseEvent e) {
				if(CUS_c1.isSelected() && CUS_c2.isSelected() && CUS_c3.isSelected() && CUS_c4.isSelected() && CUS_c5.isSelected() ) {
					CUS_all.setSelected(false);
					CUS_c1.setSelected(false);
					CUS_c2.setSelected(false);
					CUS_c3.setSelected(false);
					CUS_c4.setSelected(false);
					CUS_c5.setSelected(false);
					getContentPane().removeAll();
					repaint();
					add(Customer2Panel);
					Customer2Panel.setBounds(0,0,480,800);
					Customer2Panel.setVisible(true);
				}else {
					new Popup_Agree();
				}
				
			}
			
		});
		//--여기까지 set--//
		
		
		//--여기부터 init--//
		CustomerPanel.add(CUS_backspace);
		
		CustomerPanel.add(CUS_all);
		CustomerPanel.add(CUS_c1);
		CustomerPanel.add(CUS_c2);
		CustomerPanel.add(CUS_c3);
		CustomerPanel.add(CUS_c4);
		CustomerPanel.add(CUS_c5);
		
		CustomerPanel.add(CUS_alllb);
		CustomerPanel.add(CUS_lb1);
		CustomerPanel.add(CUS_lb2);
		CustomerPanel.add(CUS_lb3);
		CustomerPanel.add(CUS_lb4);
		CustomerPanel.add(CUS_lb5);
		
		CustomerPanel.add(CUS_next);
		//--여기까지 init--//
		
		
		//--여기부터 layouts--//
		CustomerPanel.setLayout(null);
		
		CUS_backspace.setBounds(10,10,50,50);
		
		CUS_all.setBounds(50,200,25,25);
		CUS_c1.setBounds(50,250,25,25);
		CUS_c2.setBounds(50,300,25,25);
		CUS_c3.setBounds(50,350,25,25);
		CUS_c4.setBounds(50,400,25,25);
		CUS_c5.setBounds(50,450,25,25);
		
		CUS_alllb.setBounds(100,200,200,25);
		CUS_lb1.setBounds(100,250,200,25);
		CUS_lb2.setBounds(100,300,200,25);
		CUS_lb3.setBounds(100,350,200,25);
		CUS_lb4.setBounds(100,400,200,25);
		CUS_lb5.setBounds(100,450,200,25);
		
		CUS_next.setBounds(100,600,200,80);
		//--여기까지 layouts--//
		//소비자 끝
		
		
		//소비자2
		JScrollPane scrPane = new JScrollPane();
		JTextField CUS2_idtxt,CUS2_nametxt,CUS2_addrtxt,CUS2_phonetxt,CUS2_emailtxt;
		JPasswordField CUS2_pwtxt,CUS2_pwchecktxt;
		JRadioButton CUS2_male,CUS2_female;
		JComboBox<Integer> CUS2_year,CUS2_month,CUS2_date;
		JLabel CUS2_idtip,CUS2_pwtip,CUS2_pwchecktip,CUS2_nametip,CUS2_phonetip,CUS2_emailtip,CUS2_addrtip,CUS2_gendertip,CUS2_birthtip;
		JButton CUS2_backspace,CUS2_imsibtn;
		
		boolean CUS2_id,CUS2_pw,CUS2_name,CUS2_phone,CUS2_email,CUS2_gender,CUS2_address = false;
		
		//--여기부터 set--//
		scrPane = new JScrollPane();
		scrPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		
		CUS2_backspace = new JButton();
		CUS2_backspace.addMouseListener(new MouseAdapter() {

			@Override
			public void mouseClicked(MouseEvent e) {
				getContentPane().removeAll();
				repaint();
				add(CustomerPanel);
				CustomerPanel.setBounds(0,0,480,800);
				CustomerPanel.setVisible(true);
			}
			
		});
		
		CUS2_idtxt = new JTextField(15);
		
		CUS2_nametxt = new JTextField(15);
		
		CUS2_addrtxt = new JTextField(15);
		
		CUS2_phonetxt = new JTextField(15);
		
		CUS2_emailtxt = new JTextField(15);
		
		CUS2_pwtxt = new JPasswordField(15);
		
		CUS2_pwchecktxt = new JPasswordField(15);
		
		CUS2_male = new JRadioButton();
		
		CUS2_female = new JRadioButton();
		
		CUS2_idtip = new JLabel();
		CUS2_idtip.setText("아이디를 입력하세요.");
		
		CUS2_pwtip = new JLabel();
		CUS2_pwtip.setText("비밀번호를 입력하세요.");
		
		CUS2_pwchecktip = new JLabel();
		CUS2_pwchecktip.setText("비밀번호를 입력하세요.");
		
		CUS2_nametip = new JLabel();
		CUS2_nametip.setText("이름을 입력하세요.");
		
		CUS2_phonetip = new JLabel();
		CUS2_phonetip.setText("전화번호를 입력하세요.");
		
		CUS2_emailtip = new JLabel();
		CUS2_emailtip.setText("이메일을 입력하세요.");
		
		CUS2_addrtip = new JLabel();
		CUS2_addrtip.setText("주소를 입력하세요.");
		
		CUS2_gendertip = new JLabel();
		CUS2_gendertip.setText("성별을 선택하세요.");
		
		CUS2_birthtip = new JLabel();
		CUS2_birthtip.setText("생년월일을 선택하세요.");
		
		CUS2_idtxt.addKeyListener(new KeyAdapter() {

			@Override
			public void keyReleased(KeyEvent e) {
				if(CUS2_idtxt.getText().length() > 0) {
					if(!(CUS2_idtxt.getText().matches("^[a-zA-Z0-9]*$"))) {
						CUS2_idtip.setText("영어 혹은 숫자만 입력가능합니다.");
						//id = false;
					}else {
						CUS2_idtip.setText("사용 가능한 아이디입니다.");
						//id = true;
					}
				}else {
					CUS2_idtip.setText("아이디를 입력하세요.");
				}	
			}			
		});
		
		
		CUS2_nametxt.addKeyListener(new KeyAdapter() {

			@Override
			public void keyReleased(KeyEvent e) {
				if(CUS2_nametxt.getText().length() > 0) {
					if(!(CUS2_nametxt.getText().matches("^[ㄱ-ㅎㅏ-ㅣ가-힣]*$"))) {
						CUS2_nametip.setText("한글만 입력 가능합니다.");
						//name = false;
					}else {
						CUS2_nametip.setText("사용 가능한 이름입니다.");
						//name = true;
					}
				}else {
					CUS2_nametip.setText("이름을 입력하세요.");
				}
			}			
		});
		
		
		CUS2_addrtxt.addKeyListener(new KeyAdapter() {

			@Override
			public void keyReleased(KeyEvent e) {
				if(CUS2_addrtxt.getText().length() > 0) {
					//address = true;
				}else {
					//address = false;
					
				}
			}
		});
		
		
		
		CUS2_phonetxt.addKeyListener(new KeyAdapter() {

			@Override
			public void keyReleased(KeyEvent e) {
				if(CUS2_phonetxt.getText().length() > 0) {
					if(e.getKeyChar() != KeyEvent.VK_BACK_SPACE) {
						if(CUS2_phonetxt.getText().length() == 3) {
							CUS2_phonetxt.setText(CUS2_phonetxt.getText()+"-");
						}else if(CUS2_phonetxt.getText().length() == 8) {
							CUS2_phonetxt.setText(CUS2_phonetxt.getText()+"-");
						}
					}
					if(!(CUS2_phonetxt.getText().matches("^01(?:0|1|[6-9])-(?:\\d{3}|\\d{4})-\\d{4}$"))){
						CUS2_phonetip.setText("잘못된 번호입니다.");
						//phone = false;
					}else {
						CUS2_phonetip.setText("올바론 번호입니다.");
						//phone = true;
					}
				}else {
					CUS2_phonetip.setText("전화번호를 입력하세요.");
				}
			}
			
		});
		
		
		CUS2_emailtxt.addKeyListener(new KeyAdapter() {

			@Override
			public void keyReleased(KeyEvent e) {
				if(CUS2_emailtxt.getText().length() > 0) {
					if(!(CUS2_emailtxt.getText().matches("^[a-zA-Z0-9_!#$%&'*+/=?`{|}~^.-]+@[a-zA-Z0-9.-]+$"))) {
						CUS2_emailtip.setText("잘못된 이메일 양식입니다.");
						//email = false;
					}else {
						CUS2_emailtip.setText("올바른 이메일 양식입니다.");
						//email = true;
					}
				}else {
					CUS2_emailtip.setText("이메일을 입력하세요.");
				}
			}
			
		});
		
		
		CUS2_pwtxt.addKeyListener(new KeyAdapter() {

			@Override
			public void keyReleased(KeyEvent e) {
				if(CUS2_pwtxt.getPassword().length > 0) {
					if(new String(CUS2_pwchecktxt.getPassword()).equals(new String(CUS2_pwtxt.getPassword()))) {
						CUS2_pwtip.setText("비밀번호가 일치합니다.");
						if(CUS2_pwtip.getText() == "비밀번호가 일치합니다.") {
							CUS2_pwchecktip.setText("비밀번호가 일치합니다.");
						}
					}else {
						CUS2_pwtip.setText("비밀번호가 일치하지 않습니다.");
					}
				}else {
					CUS2_pwtip.setText("비밀번호를 입력하세요.");
				}
			}
			
		});
		
		
		CUS2_pwchecktxt.addKeyListener(new KeyAdapter() {

			@Override
			public void keyReleased(KeyEvent e) {
				if(CUS2_pwchecktxt.getPassword().length > 0) {
					if(new String(CUS2_pwtxt.getPassword()).equals(new String(CUS2_pwchecktxt.getPassword()))) {
						CUS2_pwchecktip.setText("비밀번호가 일치합니다.");
						if(CUS2_pwchecktip.getText() == "비밀번호가 일치합니다.") {
							CUS2_pwtip.setText("비밀번호가 일치합니다.");
						}
						//pw = true;
					}else {
						CUS2_pwchecktip.setText("비밀번호가 일치하지 않습니다.");
						//pw = false;
					}
				}else {
					CUS2_pwchecktip.setText("비밀번호를 입력하세요.");
				}
			}
			
		});
		
		
		
		CUS2_male.addItemListener(new ItemListener() {

			@Override
			public void itemStateChanged(ItemEvent e) {
				CUS2_female.setSelected(false);
				//gender = true;
			}			
		});
		
		
		CUS2_female.addItemListener(new ItemListener() {

			@Override
			public void itemStateChanged(ItemEvent e) {
				CUS2_male.setSelected(false);
				//gender = true;
			}			
		});
		
		CUS2_year = new JComboBox<>();
		for(int i=1900 ; i<2020 ; ++i) {
			CUS2_year.addItem(i);
		}
		
		CUS2_month = new JComboBox<>();
		for(int i=1 ; i<13 ; ++i) {
			CUS2_month.addItem(i);
		}
		
		CUS2_date = new JComboBox<>();
		for(int i=1 ; i<32 ; ++i) {
			CUS2_date.addItem(i);
		}
		
		
		
		CUS2_imsibtn = new JButton("가입하기");
		CUS2_imsibtn.addMouseListener(new MouseAdapter() {

			@Override
			public void mouseClicked(MouseEvent e) {
				getContentPane().removeAll();
				repaint();
				add(CreateSuccess);
				CreateSuccess.setBounds(0,0,480,800);
				CreateSuccess.setVisible(true);
				
				//데이터베이스에 입력한거 넣기 작업하기
			}
			
		});
		//--여기까지 set--//
		
		
		//--여기부터 init--//
		Customer2Panel.add(CUS2_backspace);
		Customer2Panel.add(CUS2_idtxt);
		Customer2Panel.add(CUS2_pwtxt);
		Customer2Panel.add(CUS2_pwchecktxt);
		Customer2Panel.add(CUS2_nametxt);
		Customer2Panel.add(CUS2_addrtxt);
		Customer2Panel.add(CUS2_phonetxt);
		Customer2Panel.add(CUS2_emailtxt);
		Customer2Panel.add(CUS2_male);
		Customer2Panel.add(CUS2_female);
		Customer2Panel.add(CUS2_year);
		Customer2Panel.add(CUS2_month);
		Customer2Panel.add(CUS2_date);
		Customer2Panel.add(CUS2_idtip);
		Customer2Panel.add(CUS2_pwtip);
		Customer2Panel.add(CUS2_pwchecktip);
		Customer2Panel.add(CUS2_nametip);
		Customer2Panel.add(CUS2_addrtip);
		Customer2Panel.add(CUS2_phonetip);
		Customer2Panel.add(CUS2_emailtip);
		Customer2Panel.add(CUS2_gendertip);
		Customer2Panel.add(CUS2_birthtip);
		
		Customer2Panel.add(CUS2_imsibtn);
		//--여기까지 init--//
		
		
		
		//--여기부터 layouts--//
		Customer2Panel.setLayout(null);
		CUS2_backspace.setBounds(10,0,25,25);
		CUS2_idtxt.setBounds(10,50,200,35);
		CUS2_pwtxt.setBounds(10,100,200,35);
		CUS2_pwchecktxt.setBounds(10,150,200,35);
		CUS2_nametxt.setBounds(10,200,200,35);
		CUS2_addrtxt.setBounds(10,250,200,35);
		CUS2_phonetxt.setBounds(10,300,200,35);
		CUS2_emailtxt.setBounds(10,350,200,35);
		CUS2_male.setBounds(10,400,35,35);
		CUS2_female.setBounds(60,400,35,35);
		CUS2_year.setBounds(10,450,60,35);
		CUS2_month.setBounds(70,450,60,35);
		CUS2_date.setBounds(130,450,60,35);
		CUS2_idtip.setBounds(250,50,150,35);
		CUS2_pwtip.setBounds(250,100,150,35);
		CUS2_pwchecktip.setBounds(250,150,150,35);
		CUS2_nametip.setBounds(250,200,150,35);
		CUS2_addrtip.setBounds(250,250,150,35);
		CUS2_phonetip.setBounds(250,300,150,35);
		CUS2_emailtip.setBounds(250,350,150,35);
		CUS2_gendertip.setBounds(250,400,150,35);
		CUS2_birthtip.setBounds(250,450,150,35);
		
		CUS2_imsibtn.setBounds(100,600,200,80);
		//--여기까지 layouts--//
		
		Customer2Panel.setVisible(true);
		//소비자2 끝
		
		
		//팝업 - 회원가입 완료
		
		JLabel CS_announce;
		JButton CS_ok;
		
		
		CS_announce = new JLabel("축하합니다! 회원가입이 완료되었습니다.");
		CS_ok = new JButton("확인");
		CS_ok.addMouseListener(new MouseAdapter() {

			@Override
			public void mouseClicked(MouseEvent e) {
				CUS2_idtxt.setText(null);
				CUS2_nametxt.setText(null);
				CUS2_addrtxt.setText(null);
				CUS2_phonetxt.setText(null);
				CUS2_emailtxt.setText(null);
				
				CUS2_pwtxt.setText(null);
				CUS2_pwchecktxt.setText(null);
				
				CUS2_male.setSelected(false);
				CUS2_female.setSelected(false);
				
				getContentPane().removeAll();
				repaint();
				add(LoginPanel);
				LoginPanel.setBounds(0,0,480,800);
				LoginPanel.setVisible(true);
			}
			
		});
		
		CreateSuccess.add(CS_announce);
		CreateSuccess.add(CS_ok);
		
		setLayout(null);
		CS_announce.setBounds(20,140,200,50);
		CS_ok.setBounds(70,270,100,70);
	}
	
	

	public static void main(String[] args) {
		new Start();
		
	}

}
